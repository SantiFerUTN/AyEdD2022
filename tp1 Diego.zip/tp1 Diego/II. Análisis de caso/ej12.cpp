#include <iostream>

using namespace std;

int main(){

    //Declaraciones
    float a, b, c = 0;

    //Consigna

    cout << "A continuación se le pedirá que ingrese 3 medidas y se le dirá si con ellas se puede o no formar un triángulo" << endl;
    cout << endl;
    cout << "Ingrese medida del lado A: ";
    cin >> a;
    cout << "Ingrese medida del lado B: ";
    cin >> b;
    cout << "Ingrese medida del lado C: ";
    cin >> c;
    cout << endl;

    //Calculo e imrpimo en pantalla la respuesta

    if(a<(b+c) && b<(a+c) && c<(a+b)){

        cout << "Forman triángulo" << endl;

    }else{

        cout << "No forman triángulo" << endl;

    }

    cout << endl;

    return 0;
    
}