#include <iostream>

using namespace std;

int main(){

    //Declaraciones
    
    int edad = 0;

    //Consigna

    cout << "Ingrese la edad: ";
    cin >> edad;

    //Valido e imprimo en pantalla

    if(edad <= 12){

        cout << "Es menor" << endl;

    }else if(12 < edad && edad < 19){

        cout << "Es cadete" << endl;

    }else if(18 < edad && edad < 27){

        cout << "Es juvenil" << endl;

    }else{

        cout << "Es mayor" << endl;

    }

    return 0;

}