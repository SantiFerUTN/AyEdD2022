#include <iostream>
#include <locale.h>

using namespace std;

int main(){

	setlocale(LC_ALL, "Spanish");
	
    //Declaraciones

    int ingreso, fecha1, fecha2;

    //Consigna

    cout << "A continuación se le pedirá que ingrese 2 fechas pasadas y se le dirá cuál es mayor\n";
    
    //Ingreso fecha 1

    cout << "\nIngrese la 1ra fecha\n";
    
    cout << "Día: ";
    cin >> ingreso;
    fecha1 = ingreso;
    
    cout << "Mes: ";
    cin >> ingreso;
    fecha1 = fecha1+ingreso*100;
    
    cout << "Año: ";
    cin >> ingreso;
    fecha1= fecha1+ingreso*10000;

    //Ingreso fecha 2

    cout << "\nIngrese la 2da fecha\n";
    
    cout << "Día: ";
    cin >> ingreso;
    fecha2 = ingreso;
    
    cout << "Mes: ";
    cin >> ingreso;
    fecha2 = fecha2+ingreso*100;
    
    cout << "Año: ";
    cin >> ingreso;
    fecha2= fecha2+ingreso*10000;
    
    //Comparación e impresión
    
    if(fecha1>fecha2)
        cout<<"\nLa primer fecha ingresada es la más reciente\n";
    else
    if(fecha2>fecha1) 
        cout<<"\nLa segunda fecha ingresada es la más reciente\n";
    else 
	    cout<<"\nLas dos fechas ingresadas son iguales\n";
    
    return 0;
}