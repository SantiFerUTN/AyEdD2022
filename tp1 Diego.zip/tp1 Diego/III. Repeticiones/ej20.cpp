#include <iostream>

using namespace std;

/*
Se realiza una inspección en una fábrica de pinturas, y se detectaron 20 infracciones. De
cada infracción se tomó nota de los siguientes datos:
- Tipo de Infracción (1, 2, 3, ó 4)
- Motivo de la infracción
- Valor de la multa
- Gravedad de la infracción (‘L’,‘M’, ‘G’)
Se pide informar al final del proceso:
Los valores totales de la multa a pagar de acuerdo al tipo de gravedad.
La leyenda “Clausurar fábrica” si la cantidad de infracciones 3 y 4 con gravedad “G” sean mayor a 3.
*/

int main(){
	
	int tipo, valor, totalL=0, totalM=0, totalG=0, contador=0;
	char gravedad, motivo[80+1];
	
	for (int i=0;i<5;i++){
		
		//Ingreso de datos
		
		cout << "Ingrese el tipo de multa (1, 2, 3 o 4): " << endl;
		cin >> tipo;
		cout << "Ingrese el motivo de la multa (sin espacios): " << endl;
		cin >> motivo;
		cout << "Ingrese el valor de la multa: " << endl;
		cin >> valor;
		cout << "Ingrese la gravedad de la multa (L, M o G): " << endl;
		cin >> gravedad;
		cout << endl;
		
		//Procesamiento de datos
		
		if(gravedad=='L'){
			totalL=totalL+valor;	
		}	
		
		if(gravedad=='M'){
			totalM=totalM+valor;	
		}	
				
		if(gravedad=='G'){
			totalG=totalG+valor;
			if(tipo>2){
				contador++;
			}
		}
		
	}
	
	//Mostrar en pantalla
	
	cout << "El valor a pagar por las infracciones leves es de: $" << totalL << endl;
	cout <<"El valor a pagar por las infracciones medias es de: $" << totalM << endl;
	cout << "El valor a pagar por las infracciones graves es de: $" << totalG << endl << endl;
	
	if(contador>3) cout << " Clausurar fabrica" << endl << endl;
	
	return 0;
}