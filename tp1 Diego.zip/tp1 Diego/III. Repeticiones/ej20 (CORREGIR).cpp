#include <iostream>

using namespace std;

int main(){
	
	int tipo, valor, totalL=0, totalM=0, totalG=0, contador=0;
	char gravedad, motivo[80+1];
	
	for (int i=0;i<20;i++){
		
		//Ingreso de datos
		
		cout<<"Ingrese el tipo de multa (1, 2, 3 o 4): "<<endl;
		cin>>tipo;
		cout<<"Ingrese el motivo de la multa: "<<endl;
		cin>>motivo;
		cout<<"Ingrese el valor de la multa: "<<endl;
		cin>>valor;
		cout<<"Ingrese la gravedad de la multa (L, M o G): "<<endl;
		cin>>gravedad;
		cout<<endl;
		
		//Procesamiento de datos
		
		if(gravedad=='L'){
			totalL=totalL+valor;	
		}	
		
		if(gravedad=='M'){
			totalM=totalM+valor;	
		}	
				
		if(gravedad=='G'){
			totalG=totalG+valor;
			if(tipo>2){
				contador++;
			}
		}
		
	}
	
	//Mostrar en pantalla
	
	cout<<"El valor a pagar por las infracciones leves es de: $"<<totalL<<endl;
	cout<<"El valor a pagar por las infracciones medias es de: $"<<totalM<<endl;
	cout<<"El valor a pagar por las infracciones graves es de: $"<<totalG<<endl;
	cout<<endl;
	
	if(contador>3) cout<<"Clausurar fabrica"<<endl;
	
	return 0;
}