#include <iostream>

using namespace std;

int main(){

    //Declaraciones
    int equipos = 0, nroEquipo = 0, puntos = 0;
    char codResultado;

    //Pedimos que ingrese la cantidad de equipos

    cout << "Ingrese la cantidad de equipos que participaron en el torneo: ";
    cin >> equipos;

    //Se evalúan los puntajes de cada equipo
    
    for (int i = 0; i < equipos; i++){

        cout << "Ingrese el número de equipo: ";
        cin >> nroEquipo;

        for(int j = 0; j < equipos-1; j++){

            cout << "Ingrese el resultado: ";
            cin >> codResultado;

            if(codResultado == 'E'){

                puntos ++;

            }else if(codResultado == 'G'){

                puntos += 3;

            }

        }

        //Se imprime en pantalla los resultados del equipo evaluado

        cout << endl << "El equipo número " << nroEquipo << " sumó " << puntos << " puntos" << endl << endl;

        puntos = 0; //Se resetean la cantidad de puntos

    }
    
    return 0;

}