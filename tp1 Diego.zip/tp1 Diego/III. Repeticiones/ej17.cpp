#include <iostream>

using namespace std;

int main(){
    
    //Declaraciones

    int suma = 0;

    //Recorro e imprimo los números del 1 al 100 y su suma

    for (int i = 1; i <= 100; i++){

        cout << i << endl;
        suma = suma + i;

    }

    //Imprimo en pantalla su suma

    cout << "La sumatoria de los primeros 100 números naturales es: " << suma << endl;
    cout << endl;

    return 0;

}