#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    int n = 0, aux = 0, metod = 0;

    //Indico los métodos posibles y pido que se seleccione uno

    cout << "Métodos a utilizar:" << endl;
    cout << "   1. Precondicional." << endl;
    cout << "   2. Postcondicional." << endl << endl;
    cout << "Seleccione el método a utilizar: ";
    cin >> metod;
    cout << endl;

    //Evalúo el método seleccionado

    if (metod != 1 && metod != 2){

        cout << "Debe ingresar un método válido." << endl;
        cout << "Vuelva a correr el programa e inténtelo nuevamente." << endl << endl;

    }else if(metod == 1){

        //1. Precondicional

        //Pido el ingreso del número

        cout << "Ingrese un número entero: ";
        cin >> n;

        //Evalúo si es par o impar y hasta que ingrese 2 veces el mismo número

        while(n != aux){

            aux = n;

            if (n%2 == 0){

                cout << "El número ingresado es par" << endl << endl;

            }else{

                cout << "El número ingresado es impar" << endl << endl;

            }

            cout << "Ingrese un número entero: ";
            cin >> n;

        }

    }else if(metod == 2){

        //2. Postcondicional

        do{

            //Guardo n en una variable auxiliar para compararla luego con el siguiente número ingresado

            aux = n;

            //Pido que ingrese un número

            cout << "Ingrese un valor entero positivo: ";
            cin >> n;

            //Comparo que el número ingresado sea distinto al anterior. Si lo es, veo si es par o impar

            if (n == aux){

                cout << endl;
                cout << "El valor ingresado es igual al anterior" << endl << endl;

            }else if (n%2 == 0){

                cout << "El número ingresado es par" << endl << endl;

            }else{

                cout << "El número ingresado es impar" << endl << endl;

            }

        }while (n != aux);

    }

    return 0;

}

/*Nos parece más adecuado el método postcondicional ya que nos evita la repetición de código para ingresar
un valor y nos permite más facilmente indicar mediante una leyenda en pantalla que el valor ingresado
es igual al anterior*/