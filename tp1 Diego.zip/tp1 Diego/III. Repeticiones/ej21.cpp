#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    int n = 0, contador = 0;

    //Pido valores mientras que sean positivos

    cout << "Debe ingresar valores. Cuando ingrese uno negativo, el programa le devolverá la cantidad de valores que ingresó." << endl;

    do{

        cout << "Ingrese un valor: ";
        cin >> n;
        contador ++;
        cout << "El último valor ingresado fue: " << n << endl;
        cout << endl;

    }while(n > 0);

    //Resto el último número sumado al contador que es el negativo para solo contar los positivos

    contador = contador-1;

    //Imprimo en pantalla el resultado

    cout << "Ingresó una cantidad de " << contador << " valores positivos." << endl;
    cout << endl;

    return 0;

}