#include<iostream>
using namespace std;

int main(){

    int i=4, x=5;

    for(i=0; i<10; i++){

        if(i<x) cout<<i;
        else cout<<i-x;

    }

    cout<<endl;
    return 0;

}