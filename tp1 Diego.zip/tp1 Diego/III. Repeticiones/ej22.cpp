#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    float sueldo = 0;
    int a = 0, b = 0, c = 0, d = 0;

    //Consigna

    cout << "A continuación le pediremos que ingrese el sueldo de distintos empleados." << endl;
    cout << "Coloque '0' para dejar de ingresar sueldos y le devolveremos los datos analizados." << endl;
    cout << endl;

    //Armo la estructura de repetición correspondiente para pedir los salarios

    do{

        //Pido el ingreso de los salarios

        cout << "Ingrese un sueldo: ";
        cin >> sueldo;

        //Valido el salario ingresado

        if(sueldo < 0){

            cout << "!El sueldo debe ser positivo!" << endl;
            a --;

        }else if(sueldo < 40520){

            a ++;

        }else if(40520 <= sueldo && sueldo < 50780){

            b ++;

        }else if(50780 <= sueldo && sueldo < 80999){

            c ++; //xD

        }else if(sueldo >= 80999){

            d ++;

        }

    }while(sueldo != 0);

    //Imprimo los resultados en pantalla

    cout << endl;
    cout << "a) Hay " << a << " empleados que ganan menos de $40.520." << endl;
    cout << "b) Hay " << b << " empleados que ganan $40.520 o más pero menos de $50.780." << endl;
    cout << "c) Hay " << c << " empleados que ganan $50.780 o más pero menos de $80.999." << endl;
    cout << "d) Hay " << d << " empleados que ganan $80.999 o más" << endl;
    cout << endl;

    return 0;

}