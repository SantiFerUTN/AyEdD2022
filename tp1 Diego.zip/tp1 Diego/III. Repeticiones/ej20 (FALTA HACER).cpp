#include <iostream>

using namespace std;

int main(){

    //Declaraciones
    
    int tipoDeInfraccion = 0;
    string motivoInfraccion = "", gravedadInfraccion = "";
    float valorMulta = 0;

    //No entiendo bien que quiere la consigna

    return 0;

}