#include <iostream>

using namespace std;

/*
Escribir un programa que al recibir como dato un número entero n, que representa la
cantidad de términos de una serie, calcule el resultado y lo informe por pantalla:

1 + 1/2 + 1/3 + 1/4 + . . . + 1/n
*/

int main(){

    //Declaraciones

    int n = 0;
    float suma = 0, aux = 0;

    //Consigna

    cout << "Ingrese un número: ";
    cin >> n;

    //Calculo la sucesión y hago la suma

    for(float i = 1; i <= n; i++){

        aux = 1/i;
        suma = suma + aux;

    }

    //Imprimo en pantalla el resultado

    cout << "El resultado de la suma de la sucesión es " << suma << endl;
    cout << endl;

    return 0;

}