#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    int n, i, a, multiplo = 0;

    //Consigna

    cout << "Ingrese un número: ";
    cin >> n;
    cout << endl;

    //Verifico los múltiplos de 3 pero que no lo sean de 5

    for(int i = 1; i < n; i++){

        multiplo += 3;

        if(multiplo%5 == 0){

            multiplo += 3;

        }
        
        //imprimo en pantalla los múltiplos que voy validando

        cout << multiplo;
        cout << endl;

    }

    cout << endl;

    return 0;

}