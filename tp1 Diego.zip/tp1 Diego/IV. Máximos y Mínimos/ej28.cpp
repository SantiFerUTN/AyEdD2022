#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    int valores = 0, n = 0, cantValores = 0, mayor = 0, menor = 0, posicionMayor = 0, posicionMenor = 0;

    //Pido que ingrese la cantidad de números que desea ingresar

    cout << "Ingrese la cantidad de números que desea ingresar: ";
    cin >> valores;
    cout << endl;

    //Repito N veces el pedido de un núemro

    for (int i = 0; i < valores; i++){

        //Pido un número

        cout << "Ingrese un número: ";
        cin >> n;

        /*Aseguro que el primer valor ingresado se guarde como máximo y mínimo para comparar en 
        base a ese primero valor el resto*/

        if(i == 0){

            mayor = n;
            menor = n;

        }

        //Valido si es mayor o igual a alguno de los otros números ingresados

        if(n >= mayor){

            mayor = n;
            posicionMayor = i + 1;

        }
        
        //Valido si es menor o igual a alguno de los otros números ingresados

        if(n <= menor){

            menor = n;
            posicionMenor = i + 1;

        }

    }

    //Imprimo los resultados en pantalla

    cout << endl << "El mayor de los números ingresados es " << mayor
        << " y se ingresó en la posición " << posicionMayor << endl << endl;

    cout << endl << "El menor de los números ingresados es " << menor
        << " y se ingresó en la posición " << posicionMenor << endl << endl;

    return 0;

}