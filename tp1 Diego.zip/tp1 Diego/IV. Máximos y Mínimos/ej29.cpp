#include <iostream>

using namespace std;

int main(){

    //Declaraciones
    int n = 0, mayor = 0, menor = 0;
    string nombre, nombreMayor, nombreMenor;

    //Armo la estructura de repetición para ingresar números

    do{

        //Pido el ingreso del nombre

        cout << "Ingrese un nombre: ";
        cin >> nombre;

        if (nombre == "FIN"){

            break;

        }else{

            //Pido el ingreso de la fecha de nacimiento

            cout << "Ingrese la fecha de nacimiento (AAAAMMDD): ";
            cin >> n;

            //Verifico si el número ingresado es mayor al más grande de los ingresados anteriormente

            if (mayor == 0 || n < mayor){

                mayor = n;
                nombreMayor = nombre;

            }else if (menor == 0 || n > menor){

                menor = n;
                nombreMenor = nombre;

            }

            cout << endl;

        }

    }while (nombre != "FIN");

    cout << "El mayor de los ingresados es: " << nombreMayor << endl;
    cout << "El menor de los ingresados es: " << nombreMenor << endl;

    return 0;

}