#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    int n = 0, mayor = 0;

    //Armo una estructura para pedir 10 veces un número

    for (int i = 0; i < 10; i++){

        //Pido el ingreso de un número

        cout << "Ingrese un número: ";
        cin >> n;

        //Verifico si el número ingresado es mayor al más grande de los ingresados anteriormente

        if (n > mayor){

            mayor = n;

        }

    }

    //Imrimo en pantalla el mayor de los números ingresados

    cout << endl << "El mayor de los números ingresados es: " << mayor << endl << endl;

    return 0;

}