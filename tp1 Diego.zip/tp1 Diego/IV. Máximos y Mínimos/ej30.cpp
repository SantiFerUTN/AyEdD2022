#include <iostream>

using namespace std;

int main(){

    //Declaraciones
    float suma = 0, contador = 0, maxNegativo = 0, minPositivo = 0, minRango = 0, promedio = 0, valor = 0;

    //Ingreso de valores
    do{

        cout << "Ingrese un valor: ";
        cin >> valor;
        suma = suma + valor;
        contador ++;

        if(maxNegativo == 0 && valor < 0){

            maxNegativo = valor;

        }else if (minPositivo == 0 && valor > 0){

            minPositivo = valor;

        }else if (valor < 0 && valor > maxNegativo){

            maxNegativo = valor;


        }else if(valor > 0 && valor < minPositivo){

            minPositivo = valor;

        }else if(valor > -17.3 && valor < 26.9){

            if (minRango == 0){

                minRango = valor;

            }else if(valor < minRango){

                minRango = valor;

            }

        }


    }while(valor != 0);

    contador--;
    promedio = suma/contador;

    //Imprimo los resultados por consola

    if (contador > 0){

        cout << endl << "El valor máximo negativo ingresado fue: " << maxNegativo << endl;
        cout << "El valor mínimo positivo ingresado fue: " << minPositivo << endl;
        cout << "El promedio de los valores ingresados fue: " << promedio << endl;
        cout << "El valor mínimo ingresado dentro del rango (-17.3 ; 26.9) fue: " << minRango << endl << endl;

    }else{

        cout << "No se han ingresado valores" << endl << endl;

    }

    return 0;

}