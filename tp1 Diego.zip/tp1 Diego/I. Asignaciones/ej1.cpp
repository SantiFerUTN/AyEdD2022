#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    int n = 0;

    //Consigna

    cout << "Ingrese un número: ";
    cin >> n;

    //Imprimo en pantalla lo pedido

    cout << "\nHas introducido el número " << n << ", gracias \n";
    cout << endl;
    
    return 0;

}