#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    int n = 0;

    //Consigna

    cout << "Ingrese un número entero: ";
    cin >> n;
    cout << endl;

    //Imprimo resultados en pantalla

    cout << "Punto a) " << n/5 << " (quinta parte del valor ingresado)" << endl;
    cout << endl;
    cout << "Punto b) " << n%5 << " (resto de la división por 5)" << endl;
    cout << endl;
    cout << "Punto c) " << (n/5)/7 << " (séptima parte del resultado del punto a)" << endl;
    cout << endl;

    return 0;

}