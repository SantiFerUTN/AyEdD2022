#include <iostream>

using namespace std;

int main(){

    //Declaración de Variables

    int n1, n2 = 0;

    //Explicación

    cout << "A continuación le pediremos que ingrese 2 números enteros." << endl;
    cout << "El programa devolverá la suma, el producto y el cociente de los mismos." << endl;
    cout << "\n";

    //Primer pedido de número

    cout << "Ingrese el 1er número: ";
    cin >> n1;
    cout << endl;

    //Segundo pedido de número

    cout << "Ingrese el 2do número: ";
    cin >> n2;
    cout << endl;

    //Se muestra el resultado de las operaciones con los números ingresados

    cout << "El resultado de la suma de los números ingresados es: " << n1 + n2 << endl;
    cout << "El resultado del producto de los números ingresados es: " << n1 * n2 << endl;
    cout << "El resultado del cociente de los números ingresados es: " << n1/n2 << endl;
    cout << "\n";

    return 0;

}