#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    int dd, mm, aaaa = 0;

    //Consigna

    cout << "Ingrese día: ";
    cin >> dd;
    cout << endl;
    cout << "Ingrese mes: ";
    cin >> mm;
    cout << endl;
    cout << "Ingrese el año: ";
    cin >> aaaa;
    cout << endl;

    //Imprimo en pantalla el resultado

    cout << "La fecha ingresada en formato (AAAAMMDD) es: " << aaaa*10000 + mm*100 + dd << endl;
    cout << endl;

    return 0;

}