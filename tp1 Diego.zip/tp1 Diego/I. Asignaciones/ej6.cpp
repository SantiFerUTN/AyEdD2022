#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    float dolares = 0, bitcoinsUsuario = 0;

    //Consigna

    cout << "Ingrese la cantidad de U$D a convertir a Bitcoin: ";
    cin >> dolares;
    cout << endl;

    //Imprimo en pantalla la conversión realizada

    cout << dolares << "U$D es el equivalente a " << dolares/35000 << " bitcoins" << endl;
    cout << endl;

    return 0;

}