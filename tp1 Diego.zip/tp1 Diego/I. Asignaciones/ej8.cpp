#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    float unPago = 0;

    /* Consigna
    
    1 cuota de $.................
    2 cuotas de $................. total $................. ( 5% de recargo)
    6 cuotas de $................. total $................. ( 30% de recargo)
    12 cuotas de $................. total $................. ( 50% de recargo)*/

    cout << "Ingrese importe a pagar por su compra: ";
    cin >> unPago;
    cout << endl;

    //Imprimo en pantalla los resultados

    cout << "1 cuota de $" << unPago << endl;
    cout << "2 cuotas de $" << (unPago + (unPago*0.05))/2 << " total $" << unPago + (unPago*0.05) << " (5% de recargo)" << endl;
    cout << "2 cuotas de $" << (unPago + (unPago*0.3))/2 << " total $" << unPago + (unPago*0.3) << " (30% de recargo)" << endl;
    cout << "2 cuotas de $" << (unPago + (unPago*0.5))/2 << " total $" << unPago + (unPago*0.5) << " (50% de recargo)" << endl;

    return 0;

}