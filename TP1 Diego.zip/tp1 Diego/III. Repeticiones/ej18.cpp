#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    int n, m, producto = 0;

    //Pido y guardo los números

    cout << "Ingrese un número n: ";
    cin >> n;
    cout << "Ingrese un número m: ";
    cin >> m;
    cout << endl;

    //Sumo sucesivamente para multiplicar n*m

    for(int i = 0; i < n; i++){

        producto = producto + m;

    }

    //Imprimo en pantalla la multiplicación

    cout << "El producto entre m y n es: " << producto << endl;
    cout << endl;

    return 0;

}