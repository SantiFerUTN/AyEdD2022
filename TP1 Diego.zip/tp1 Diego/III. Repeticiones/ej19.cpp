#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    int n = 0, contador = 0, suma = 0;
    float promedio = 0;

    //Saco las cuentas

    for(int i = 0; i < 5; i++){

        cout << "Ingrese un número: ";
        cin >> n;

        if (n > 100){

            contador ++;
            promedio = promedio + n;

        }else if (n < (-10)){

            suma = suma + n;

        }

    }

    //Valido e impimo en pantalla los resultados

    if(contador != 0){

        cout << "El promedio de los números ingresados mayores a 100 es: " << promedio/contador << endl;

    }else{

        cout << "No se ingresaron números mayores a 100" << endl;

    }

    cout << "La suma de los números menores a -10 es: " << suma << endl;
    cout << endl;

    return 0;

}