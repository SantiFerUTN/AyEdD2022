#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    int fecha = 0;

    //Consigna

    cout << "Ingrese una fecha en formato (AAAAMMDD): ";
    cin >> fecha;

    //Imprimo en pantalla lo pedido
    
    cout<<"\nEl día es: "<<fecha%100;

	fecha=fecha/100;

   	cout<<"\nEl mes es: "<<fecha%100;

	cout<<"\nEl año es: "<<fecha/100;
 
    return 0;

}