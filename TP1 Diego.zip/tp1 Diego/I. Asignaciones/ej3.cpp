#include <iostream>

using namespace std;

int main(){
    
    //Declaraciones

    float prod1 = 0, prod2 = 0, prod3 = 0;

    //Consigna
    
    cout << "Ingrese el precio del 1er producto: ";
    cin >> prod1;
    cout << endl;
    cout << "Ingrese el precio del 2do producto: ";
    cin >> prod2;
    cout << endl;
    cout << "Ingrese el precio del 3er producto: ";
    cin >> prod3;
    cout << endl;

    //Imprimo en pantalla lo pedido

    cout << "El promedio de los precios de los productos es: " << (prod1 + prod2 + prod3)/3 << endl;
    cout << endl;

    return 0;

}