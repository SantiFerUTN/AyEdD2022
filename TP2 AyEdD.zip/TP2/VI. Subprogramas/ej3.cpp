#include <iostream>

using namespace std;

//Funciónn que devuelve el nombre del mes ingresado

void calculoMes(int numMes){

    switch (numMes){

        case 1:
            cout << "Enero";
            break;
        case 2:
            cout << "Febrero";
            break;
        case 3:
            cout << "Marzo";
            break;
        case 4:
            cout << "Abril";
            break;
        case 5:
            cout << "Mayo";
            break;
        case 6:
            cout << "Junio";
            break;
        case 7:
            cout << "Julio";
            break;
        case 8:
            cout << "Agosto";
            break;
        case 9:
            cout << "Septiembre";
            break;
        case 10:
            cout << "Octubre";
            break;
        case 11:
            cout << "Noviembre";
            break;
        case 12:
            cout << "Diciembre";
            break;

    }

}

int main(){

    //Declaraciones

    int numMes = 0;

    //Consigna e ingreso de datos

    cout << "Ingrese el numero de mes y se le devolverá el nombre del mes" << endl;
    cout << "Ingrese numero de mes: ";
    cin >> numMes;
    cout << endl;

    //Se imprime el resultado en pantalla

    cout << "El mes ingresado es: ";
    calculoMes(numMes);
    cout << endl;
    
    return 0;

}