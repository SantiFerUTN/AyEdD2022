#include <iostream>

using namespace std;

//Función que toma 2 números enteros como parámetros y devuelve su suma

int suma1(int n1, int n2){

    int suma = 0;

    suma = n1 + n2;

    return suma;

}

/*Función que toma 2 números enteros como parámetros y toma un 3er parámetro como
el resultado de la suma y devuelve este último*/

int suma2(int n1, int n2, int suma2){

    suma2 = n1 + n2;

    return suma2;

}

int main(){

    //Declaraciones

    int n1 = 0, n2 = 0, suma = 0;

    //Consigna e ingreso de datos

    cout << "Ingrese 2 numeros enteros. El programa devolverá la suma de ellos" << endl;
    cout << "Ingrese el 1er numero entero: ";
    cin >> n1;
    cout << "Ingrese el 2do numero entero: ";
    cin >> n2;

    //Se imprimen en pantalla los resultados

    cout << "La suma de los numeros es: " << suma1(n1, n2) << " (utilizando la funcion suma1())" << endl << endl;
    cout << "La suma de los numeros es: " << suma2(n1, n2, suma) << " (utilizando la funcion suma2())" << endl << endl;

    return 0;

}
