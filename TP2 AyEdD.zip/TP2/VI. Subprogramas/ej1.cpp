#include <iostream>
#define pi 3.141492 //Definimos pi

using namespace std;

//Función que calcula el área de la circunferencia

float area(float r){

    float area = 0;

    area = pi*r*r;

    return area;

}

//Función que calcula el perímetro de la circunferencia

float perimetro(float r){

    float perimetro = 0;

    perimetro = 2*pi*r;

    return perimetro;

}

int main(){

    //Declaraciones

    int radio = 0;

    //Consigna e ingreso de datos

    cout << "Ingrese el radio de una circunferencia y le dirmos el perimetro y el area" << endl;
    cout << "Radio de la circunferencia: ";
    cin >> radio;

    //Se imprime en pantalla el resultado de los cálculos de área y perímetro de la circunferencia

    cout << endl << "El area de la circunferencia es " << area(radio) << " y el perimetro es " << 
    perimetro(radio) << endl << endl;

    return 0;

}