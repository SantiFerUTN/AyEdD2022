#include <iostream>

using namespace std;

//Función que calcula el factorial

int factorial(int numero){
	
	//Declaraciones

	int total = 1;
	
	//Cálculo de factorial

	for(int i = 1; i <= numero ; i++){
		total = total * i;
	}
	
	return total;
	
}

int main() {

	//Declaraciones
	
	int numero1 = 0;

	//Consigna e ingreso de datos
	
	cout << "Ingrese un número y se le devolverá su factorial\n";
	cout << "Ingrese un numero: ";
	cin >> numero1;

	//Se imprime en pantalla el resultado de lo pedido
	
	cout << "\nEl factorial de " << numero1 << " es igual a " << factorial(numero1) << ".\n";
	
	return 0;

}
