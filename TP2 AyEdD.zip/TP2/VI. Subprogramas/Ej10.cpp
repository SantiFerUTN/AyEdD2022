#include <iostream>

using namespace std; 

//Función que calcula el porcentaje de la diferencia de 2 valores

float CalcularPorcentajeDiferencia(int A, int B){

	return (B-A) *100 / (A+B);

}

int main() {

	//Declaraciones
	
	int a = 0, b = 0;
	
	//Consigna e ingreso de datos

	cout << "Se le pedira que ingrese 2 valores y se le devolvera el porcentaje de diferencia" << endl;
	cout << "Ingrese el primer valor entero: ";
	cin >> a;
	cout << "Ingrese el segundo valor entero: ";
	cin >> b;

	//Imprimo en pantalla el porcentaje de diferencia
	
	cout << "\nEl porcentaje de diferencia del " << CalcularPorcentajeDiferencia(a, b) << "%.\n";
	
	return 0;
	
}
