#include <iostream>

using namespace std;

int potencia(int base, int exponente){

	//Declaraciones
	
	int resultado = 1;
	
	for(int i=0 ; i<exponente ; i++){
		resultado*=base;
	}
	
	return resultado;

}

int main() {
	
	//Declaraciones

	int base1 = 0, exponente1 = 0;

	//Consigna e ingreso de datos
	
	cout << "Se le pedirá el ingreso de la base y exponente de una potencia y se le devolverá el resultado\n";
	cout << "Ingrese la base de la potencia (entera y positiva): ";
	cin >> base1;
	cout << "Ingrese el exponente de la potencia (entero y positivo): ";
	cin >> exponente1;

	//Se imprime el resultado del cálculo en pantalla
	
	cout << "\nEl resultado de la potencia es " << potencia(base1, exponente1) << ".\n";
		
	return 0;

}
