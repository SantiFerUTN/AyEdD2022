#include <iostream>

using namespace std;

//Función que calcula el salario de un trabajadorsegún las horas semanales trabajadas

int salario(int horas, int salarioHora){
	
	//Declaraciones

	int total = 0;
	
	total = salarioHora * horas;
	
	if(horas > 40){

		horas = horas - 40;
		total = total + (horas * 0,5 * salarioHora);

	}
	
	return total;

}

int main() {
	
	//Declaraciones

	int salarioHora = 0, horas = 0;

	//Consigna e ingreso de datos
	
	cout << "Ingrese el salario por hora del trabajador: ";
	cin >> salarioHora;
	cout << "Ingrese la cantidad de horas semanales que trabaja: ";
	cin >> horas;

	//Se imprime en pantalla el resultado del salario
	
	cout << "\nEl trabajador gana $" << salario(horas, salarioHora) << " por semana\n";
	
	return 0;
	
}
