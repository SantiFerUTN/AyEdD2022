#include <iostream>
#define iva 1.21

using namespace std; 

//Función que calcula el tiempo (Punto a)

int tiempo(int hhmm){

   return (hhmm/100)*60 + hhmm%100;

}

//Función que calcula los costos (Punto b)

float costos(float abono, int minLibres, float  cargExcedido, int minUsados){

    if(minUsados <= minLibres){

        cout << "No se excedieron los minutos del plan" << endl;

    }else{

        //Decidimos guardar el abono como variable y mostrar el exceso de minutos por pantalla

        abono += (minUsados - minLibres) * cargExcedido;
        cout << "El plan fue excedido por " << minUsados - minLibres << endl;

    }

    cout << "\nEl valor a pagar es de $";

    return abono * iva;

}

int main(){

    //Declaraciones
    
    int hhmm1 = 0, minLibres1 = 0, minUsados1 = 0;
    float abono1 = 0, cargExcedido1 = 0;
    
    //Ingreso de datos

    cout << "Ingresar el coste base del plan: ";
    cin >> abono1;
    cout << "Ingresar el tiempo libre que incluye el abono (horas, minutos): ";
    cin >> minLibres1;
    cout << "Ingresar el cargo en pesos por minuto excedente: ";
    cin >> cargExcedido1;
    cout << "Ingrese la cantidad de minutos usados: ";
    cin >> minUsados1;

    //Se imprime el resultado de lo pedido

    cout << costos(abono1, tiempo(minLibres1), cargExcedido1, tiempo(minUsados1)) << endl;

    return 0;

}



