#include <iostream>

using namespace std; 

//Función que calcula el máximo común divisor entre 2 numéros ingresados

int mcd(int a, int b){

    //Declaraciones

    int resto;

    //Se calcula el resto

    while( (resto = a%b) != 0 ){

        a = b; 
        b = resto; 

    }    

    return b;

}

int main(){

    //Declaraciones

    int a1 = 0, b1 = 0;

    //Ingreso de datos

    cout << "Se le pedirá el ingreso de 2 números y se le devolverá el maximo comun multiplo entre ellos\n";
    cout << "Ingrese el primer valor: ";
    cin >> a1;
    cout << "Ingrese el segundo valor: ";
    cin >> b1;

    //Se imprime en pantalla lo devuelto por la función

    cout << "\nEl maximo comun divisor entre los valores ingresados es " << mcd(a1, b1) << endl;

    return 0; 

}
