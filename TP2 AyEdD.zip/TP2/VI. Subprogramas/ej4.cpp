#include <iostream>

using namespace std; 

//Función que devuelve el producto entre un número entero y uno real

float producto(float x, int n){
    return x*n;
}

int main(){

    //Declaraciones

    float x1 = 0;

    int n1 = 0;

    //Ingreso de datos

    cout << "Se le pedirá el ingreso de un valor real y uno entero y el programa le devolverá el producto de los mismos\n";
    cout << "Ingrese valor real: "; 
    cin >> x1;
    cout << "Ingrese valor entero: "; 
    cin >> n1; 

    //Llamado a la función que devuelve el resultado del producto entre los datos ingresados

    cout << "El resultado del producto de los numeros ingresados es: " << producto(x1, n1) << endl;

    return 0; 
    
}