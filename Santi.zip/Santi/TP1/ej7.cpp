#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    int cuadrado, cubo = 0;

    //Recorro los número del 0 al 10

    for(int i = 0; i < 11; i++){

        //Cálculos

        cuadrado = i*i;
        cubo = i*i*i;

        //Imprimo en pantalla los resultados

        cout << "Resultados para " << i << endl;
        cout << "Cuadrado: " << cuadrado << endl;
        cout << "Cubo: " << cubo << endl;
        cout << "\n";

    }
    
    return 0;

}