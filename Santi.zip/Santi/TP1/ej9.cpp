#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    int n1, n2, tipoDato = 0;

    //Consigna
    //Pido que ingresen el 1er número

    cout << "A continuación se le pedirá que ingrese 2 números enteros positivos." << endl;
    cout << "Ingrese el primer número: ";
    cin >> n1;
    cout << "\n";

    tipoDato = sizeof(n1); //Intento de validar número entero que no funca

    //Compruebo que el 1er número sea positivo

    while (n1 < 0 & tipoDato != 2){

        cout << "!El número debe ser entero y positivo!" << endl;
        cout << "Inténtelo nuevamente...";
        cout << "Ingrese el primer número: ";
        cin >> n1;
        tipoDato = sizeof(n1);
        cout << "\n";

    }

    //Pido que ingresen el 2do número

    cout << "Ahora ingrese el segundo número: ";
    cin >> n2;

    tipoDato = sizeof(n2);

    //Compruebo que el 2do número sea positivo

    while (n2 < 0 & tipoDato != 2){

        cout << "!El número debe ser entero y positivo!" << endl;
        cout << "Inténtelo nuevamente...";
        cout << "Ingrese el segundo número: ";
        cin >> n2;
        tipoDato = sizeof(n2);
        cout << "\n";

    }

    //Cálculos



    int suma = n1 + n2;
    int resta = n1 - n2;
    int producto = n1 * n2;
    int division = n1/n2;

    //Imprimo en pantalla los resultados

    cout << "La suma de los números es: " << suma << endl;
    cout << "\n";
    cout << "La resta de los números es: " << resta << endl;
    cout << "\n";
    cout << "El producto de los números es: " << producto << endl;
    cout << "\n";
    cout << "El resultado de la división de los números es: " << division << endl;
    cout << "\n";

    return 0;

}