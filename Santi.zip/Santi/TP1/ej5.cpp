#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    int n = 0;

    //Consigna

    cout << "Ingrese un número: ";
    cin >> n;
    cout << "\n";

    //Cálculos

    int diametro = 2 * n;
    float circunferencia = 3.14 * diametro;
    float area = 3.14 * n * n;

    //Imprimo en pantalla los resultados

    cout << "El diámetro del círculo es: " << diametro << endl;
    cout << "\n";
    cout << "La circunferencia del círculo es: " << circunferencia << endl;
    cout << "\n";
    cout << "El área del círculo es: " << area << endl;
    cout << "\n";

    return 0;

}