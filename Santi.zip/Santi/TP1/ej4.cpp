#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    int n1, n2, n3, mayor, menor = 0;

    //Consigna e ingreso de núemros

    cout << "A continuación se le pedirá que ingrese 3 números." << endl;
    cout << "\n";
    cout << "Ingrese el 1er número: ";
    cin >> n1;
    cout << "\n";
    cout << "Ingrese el 2do número: ";
    cin >> n2;
    cout << "\n";
    cout << "Ingrese el 3er número: ";
    cin >> n3;
    cout << "\n";

    //Operaciones

    int suma = n1 + n2 + n3;
    double promedio = suma/3;
    int producto = n1 * n2 * n3;

    //Calculo el mayor

    if(n1 > n2){
        if(n1 > n3){
            mayor = n1;
        }else{
            mayor = n3;
        }
    }else{
        mayor = n2;
    }

    //Calculo el menor

    if(n1 < n2){
        if(n1 < n3){
            menor = n1;
        }else{
            menor = n3;
        }
    }else{
        menor = n2;
    }

    //Imprimo los resultados en pantalla

    cout << "Suma = " << suma << endl;
    cout << "Promedio = " << promedio << endl;
    cout << "Producto = " << producto << endl;
    cout << "Mayor = " << mayor << endl;
    cout << "Menor = " << menor << endl;
    cout << "\n";

    return 0;

}