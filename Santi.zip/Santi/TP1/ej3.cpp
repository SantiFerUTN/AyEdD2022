#include <iostream>

using namespace std;

int main(){

    //Declaración de variables

    int opcion = 0;

    //Consigna y selección

    cout << "Imprimir números del 1 al 4" << endl;
    cout << "\n";
    cout << "   1. Utilizando un solo operador de inserción de flujo." << endl;
    cout << "   2. Una única sentenica con 4 operadores de inserción de flujo." << endl;
    cout << "   3. Utilizando cuatro sentencias." << endl;
    cout << "\n";
    cout << "Selecciones¿ una opción: ";
    cin >> opcion;
    cout << "\n";

    //Resulución de las diferentes opciones

    switch(opcion){

        case 1:
            
            cout << "1, 2, 3, 4 \n";
            break;

        case 2:

            cout << "1, " << "2, " << "3, " << "4 \n";
            break;

        case 3:

            cout << "1, ";
            cout << "2, ";
            cout << "3, ";
            cout << "4 \n";
            break;

    }

    return 0;

}