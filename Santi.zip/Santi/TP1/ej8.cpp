#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    int n, digito, aux = 0;
    int lista [4];

    //Consigna

    cout << "Ingrese un número de entero de 5 dígitos: " << endl;
    cin >> n;
    cout << "\n";

    while (n > 100000 | n < 9999){

        cout << "!Debe ingresar un número de 5 dígitos!" << endl;
        cout << "Intente nuevamente: ";
        cin >> n;

    }

    //Recorro el número y guardo sus dígitos en un vector
    
    for (int i = 5; i > 0; i--){

        digito = n % 10;
        aux = n / 10;
        n = aux;

        lista[i] = digito;

    }

    //Muestro el vector de dígitos creado anteriormente

    for (int j = 1; j < 6; j++){

        cout << lista[j] << endl;

    }

    return 0;

}