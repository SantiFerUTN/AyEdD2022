#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    float unPago, dosPagos, seisPagos, docePagos = 0;

    /* Consigna
    
    1 cuota de $.................
    2 cuotas de $................. total $................. ( 5% de recargo)
    6 cuotas de $................. total $................. ( 30% de recargo)
    12 cuotas de $................. total $................. ( 50% de recargo)*/

    cout << "Ingrese importe a pagar por su compra: ";
    cin >> unPago;
    cout << endl;

    //Cálculos

    dosPagos = unPago + (unPago*5/100);
    seisPagos = unPago + (unPago*30/100);
    docePagos = unPago + (unPago*50/100);

    //Imprimo en pantalla los resultados

    cout << "El precio final pagando en 2 cuotas es de: " << dosPagos << endl;
    cout << endl;
    cout << "El precio final pagando en 6 cuotas es de: " << seisPagos << endl;
    cout << endl;
    cout << "El precio final pagando en 12 cuotas es de: " << docePagos << endl;
    cout << endl;

    return 0;

}