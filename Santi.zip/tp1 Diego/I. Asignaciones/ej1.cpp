#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    int n = 0;

    //Consigna

    cout << "Ingrese un número: ";
    cin >> n;
    cout << endl;

    //Imprimo en pantalla lo pedido

    cout << "Has introducido el número " << n << ", gracias" << endl;
    cout << endl;
    
    return 0;

}