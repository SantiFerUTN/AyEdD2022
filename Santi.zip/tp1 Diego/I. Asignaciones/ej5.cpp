#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    int fecha, dd, mm, aaaa = 0;

    //Consigna

    cout << "Ingrese una fecha en formato (AAAAMMDD): ";
    cin >> fecha;
    cout << endl;

    //Cálculos

    aaaa = fecha/10000;
    fecha = fecha%10000;

    mm = fecha/100;
    dd = fecha%100;

    //Imprimo lo calculado en pantalla

    cout << "El día es : " << dd << endl;
    cout << "El mes es: " << mm << endl;
    cout << "El año es: " << aaaa << endl;
    cout << endl;

    return 0;

}