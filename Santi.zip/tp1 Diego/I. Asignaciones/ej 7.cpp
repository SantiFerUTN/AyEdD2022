#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    int n, resto = 0;
    float quintaParte, septimaParteDeA = 0;

    //Consigna

    cout << "Ingrese un número entero: ";
    cin >> n;
    cout << endl;

    //Cálculos
    //a)

    quintaParte = n/5;

    //b)

    resto = n%5;

    //c)

    septimaParteDeA = quintaParte/7;

    //Imprimo resultados en pantalla

    cout << "Punto a) " << quintaParte << " (quinta parte del valor ingresado)" << endl;
    cout << endl;
    cout << "Punto b) " << resto << " (resto de la división por 5)" << endl;
    cout << endl;
    cout << "Punto c) " << septimaParteDeA << " (séptima parte del resultado del punto a)" << endl;
    cout << endl;

    return 0;

}