#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    float dolares = 0;
    float valorBitcoin = 35000;
    float bitcoinsUsuario = 0;

    //Consigna

    cout << "Ingrese la cantidad de U$D a convertir a Bitcoin: ";
    cin >> dolares;
    cout << endl;

    //Cálculo

    bitcoinsUsuario = dolares/valorBitcoin;

    //Imprimo en pantalla la conversión realizada

    cout << dolares << "U$D es el equivalente a " << bitcoinsUsuario << " bitcoins" << endl;
    cout << endl;

    return 0;

}