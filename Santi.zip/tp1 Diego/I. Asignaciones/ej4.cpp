#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    int dd, mm, aaaa = 0;

    //Consigna

    cout << "Ingrese día: ";
    cin >> dd;
    cout << endl;
    cout << "Ingrese mes: ";
    cin >> mm;
    cout << endl;
    cout << "Ingrese el año: ";
    cin >> aaaa;
    cout << endl;

    //Convierto a string los números para juntarlos en una sola fecha

    string fechaCompleta = to_string(aaaa) + to_string(mm) + to_string(dd);

    //Imprimo en pantalla el resultado

    cout << "La fecha ingresada en formato (AAAAMMDD) es: " << fechaCompleta << endl;
    cout << endl;

    return 0;

}