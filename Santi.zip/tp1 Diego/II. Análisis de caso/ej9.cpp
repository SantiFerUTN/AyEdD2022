#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    int n1, n2 = 0;

    //Consigna

    cout << "Ingrese el 1er número entero: ";
    cin >> n1;
    cout << endl;
    cout << "Ingrese el 2do número entero: ";
    cin >> n2;
    cout << endl;

    //Calculo mayor e imprimo en pantalla la leyenda correspondiente

    if(n1==n2){

        cout << "Los números ingresados son iguales" << endl;

    }else if(n1>n2){

        cout << "El 1er número ingresado es mayor al 2do" << endl;

    }else{

        cout << "El 2do número ingresado es mayor al 1ro" << endl;

    }

    cout << endl;

    return 0;
    
}