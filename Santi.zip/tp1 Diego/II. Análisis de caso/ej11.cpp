#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    int dd, mm, aaaa, dd2, mm2, aaaa2 = 0;
    string fechaMasReciente = "";

    //Consigna

    cout << "A continuación se le pedirá que ingrese 2 fechas y se le dirá cuál es mayor" << endl;
    cout << endl;
    
    //Fecha 1

    cout << "Ingrese la 1ra fecha" << endl;
    cout << "Día: ";
    cin >> dd;
    cout << "Mes: ";
    cin >> mm;
    cout << "Año: ";
    cin >> aaaa;
    cout << endl;

    //Fecha 2

    cout << "Ingrese la 2da fecha" << endl;
    cout << "Día: ";
    cin >> dd2;
    cout << "Mes: ";
    cin >> mm2;
    cout << "Año: ";
    cin >> aaaa2;
    cout << endl;

    //Cálculos

    if(aaaa==aaaa2 && mm==mm2 && dd==dd2){

        cout << "!Puso las mismas fechas!" << endl;
        cout << endl;
        return 0;

    }else if(aaaa==aaaa2 && mm==mm2){

        if(dd>dd2){

            fechaMasReciente = to_string(dd) + "-" + to_string(mm) + "-" + to_string(aaaa);

        }else{

            fechaMasReciente = to_string(dd2) + "-" + to_string(mm2) + "-" + to_string(aaaa2);

        }

    }else if(aaaa==aaaa2){

        if(mm>mm2){

            fechaMasReciente = to_string(dd) + "-" + to_string(mm) + "-" + to_string(aaaa);

        }else{

            fechaMasReciente = to_string(dd2) + "-" + to_string(mm2) + "-" + to_string(aaaa2);

        }

    }else if(aaaa>aaaa2){

        fechaMasReciente = to_string(dd) + "-" + to_string(mm) + "-" + to_string(aaaa);

    }else{

        fechaMasReciente = to_string(dd2) + "-" + to_string(mm2) + "-" + to_string(aaaa2);

    }

    //Imprimo en pantalla la fecha más reciente

    cout << "La fecha más reciente es: " << fechaMasReciente << endl;
    cout << endl;

    return 0;
    
}