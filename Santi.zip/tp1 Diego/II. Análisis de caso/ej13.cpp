#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    int l1, l2, l3 = 0;
    string tipoTriangulo = "";

    //Consigna

    cout << "A continuación se le pedirá que ingrese 3 medidas y se le dirá, en caso de que puedan formar un triángulo, qué tipo de triángulo fromaron" << endl;
    cout << endl;
    cout << "Ingrese medida del lado 1: ";
    cin >> l1;
    cout << "Ingrese medida del lado 2: ";
    cin >> l2;
    cout << "Ingrese medida del lado 3: ";
    cin >> l3;
    cout << endl;

    //Calculo e imrpimo en pantalla la respuesta

    if(l1<(l2+l3) && l2<(l1+l3) && l3<(l1+l2)){

        if(l1==l2 && l2==l3){

            tipoTriangulo = "equilátero";

        }else if(l1==l2 || l2==l3 || l1==l3){

            tipoTriangulo = "isóseles";

        }else{

            tipoTriangulo = "escaleno";

        }

    }else{

        cout << "No forman triángulo" << endl;
        return 0;

    }

    cout << "El tipo de triángulo formado por los lados ingresados es " << tipoTriangulo << endl;
    cout << endl;

    return 0;
    
}