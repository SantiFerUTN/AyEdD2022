#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    int mes, anio, diasMes = 0;
    bool esBisiesto = false;

    //Consigna

    cout << "A continuación se le pedirá que ingrese un mes y un año. Se le dará como respuesta la cantidad de días que tiene ese mes." << endl;
    cout << endl;
    cout << "Ingrese el número de mes que desee (1-12): ";
    cin >> mes;
    cout << "Ingrese el año que desee:";
    cin >> anio;
    cout << endl;

    //Calculo si es año bisiesto

    if(anio%4 == 0 && anio%100 != 0 || anio%100 != 0 && anio%400 == 0){

        esBisiesto = true;

    }else{

        esBisiesto = false;

    }

    switch(mes){

        case 1:
            diasMes = 31;

        case 2:

            if(esBisiesto == true && mes == 2){

                diasMes = 29;

            }else{

                diasMes = 28;

            }

        case 3:
            diasMes = 31;

        case 4:
            diasMes = 30;

        case 5:
            diasMes = 31;

        case 6:
            diasMes = 30;

        case 7:
            diasMes = 31;

        case 8:
            diasMes = 31;

        case 9:
            diasMes = 30;

        case 10:
            diasMes = 31;

        case 11:
            diasMes = 30;

        case 12:
            diasMes = 31;

    }

    //Imprimo en pantalla la cantidad de días que tiene el mes según el año

    cout << "La cantidad de días del mes ingresado según el año ingresado es " << diasMes << endl;
    cout << endl;

    return 0;
    
}