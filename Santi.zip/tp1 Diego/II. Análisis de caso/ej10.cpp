#include <iostream>

using namespace std;

int main(){

    //Declaraciones

    int n1, n2, n3 = 0;

    //Consigna

    cout << "A continuación le pediremos que ingrese 3 números para luego devolvérselos ordenados en forma descendente" << endl;
    cout << endl;
    cout << "Ingrese el 1er número: ";
    cin >> n1;
    cout << endl;
    cout << "Ingrese el 2do número: ";
    cin >> n2;
    cout << endl;
    cout << "Ingrese el 3er número: ";
    cin >> n3;
    cout << endl;

    //Calculo orden descendente e imprimo en pantalla

    if(n1>n2 && n1>n3){

        if(n2>n3){

            cout << "El mayor es " << n1 << ", le sigue " << n2 << " y por último " << n3 << endl;

        }else{

            cout << "El mayor es " << n1 << ", le sigue " << n3 << " y por último " << n2 << endl;

        }

    }else if(n2>n1 && n2>n3){

        if(n1>n3){

            cout << "El mayor es " << n2 << ", le sigue " << n1 << " y por último " << n3 << endl;

        }else{

            cout << "El mayor es " << n2 << ", le sigue " << n3 << " y por último " << n1 << endl;

        }

    }else if(n3>n1 && n3>n2){

        if(n1>n2){

            cout << "El mayor es " << n3 << ", le sigue " << n1 << " y por último " << n2 << endl;

        }else{

            cout << "El mayor es " << n3 << ", le sigue " << n2 << " y por último " << n1 << endl;

        }

    }

    cout << endl;

    return 0;
    
}